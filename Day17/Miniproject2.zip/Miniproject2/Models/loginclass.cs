﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Miniproject2.Models
{
    public class loginclass
    {

        public string LoginName { get; set; }
        public string Password { get; set; }

        public bool isRemember { get; set; }
    }
}