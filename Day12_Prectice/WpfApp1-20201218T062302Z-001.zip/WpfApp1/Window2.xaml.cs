﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
        }

        private void txtNum1_KeyDown(object sender, KeyEventArgs e)
        {


            //MessageBox.Show(KeyInterop.VirtualKeyFromKey(e.Key).ToString());
            //MessageBox.Show(e.Key.ToString());
            //e.Handled = true;

        }

       
        private void txtNum1_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            MessageBox.Show(e.Text);
           
        }
    }
}
